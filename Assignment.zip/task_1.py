a = 5
b = "text string"

print(a, " ", b)

n_s = input("Введите число:\n")
n = int(n_s)
s = input("Введите текст:\n")

print("Введённое число: ", n)
print("Введённая строка: ", s)
