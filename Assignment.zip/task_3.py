n = int(input("Введите число:\n"))

result = n + int(str(n) * 2) + int(str(n) * 3)

print(result)
